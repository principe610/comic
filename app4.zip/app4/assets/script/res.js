if(window.innerHeight>window.innerWidth) {
	document.getElementsByTagName('style')[0].innerHTML=document.getElementsByTagName('style')[0].innerHTML+".sec{width:87%}";
} else {
	document.getElementsByTagName('style')[0].innerHTML=document.getElementsByTagName('style')[0].innerHTML+".sec{width:45%}";
}